//
//  DaysViewController.swift
//  PF
//
//  Created by Maleni Danae on 03/12/18.
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio. All rights reserved.
//

import UIKit

class DaysViewController: UIViewController {

    @IBOutlet weak var DAYIMAGE: UIImageView!
    @IBOutlet weak var DAYNAME: UILabel!
    
    var Days: DaysData!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DAYNAME.text = Days.Dayname
        DAYIMAGE.image = Days.Dayimage

    }

}
