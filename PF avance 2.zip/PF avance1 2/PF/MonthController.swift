//
//  MonthController.swift
//  PF
//
//  Created by Maleni Danae on 03/12/18.
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio. All rights reserved.
//

import UIKit

class MonthController: UIViewController, UITableViewDataSource{
    
    @IBOutlet weak var MONTHTABLE: UITableView!
    var Month = [MonthData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Month.append(MonthData(monthname: "Enero", monthimage: UIImage(named: "Enero")!))
        Month.append(MonthData(monthname: "Febrero", monthimage: UIImage(named: "Febrero")!))
        Month.append(MonthData(monthname: "Marzo", monthimage: UIImage(named: "Marzo")!))
        Month.append(MonthData(monthname: "Abril", monthimage: UIImage(named: "Abril")!))
        Month.append(MonthData(monthname: "Mayo", monthimage: UIImage(named: "Mayo")!))
        Month.append(MonthData(monthname: "Junio", monthimage: UIImage(named: "Junio")!))
        Month.append(MonthData(monthname: "Julio", monthimage: UIImage(named: "Julio")!))
        Month.append(MonthData(monthname: "Agosto", monthimage: UIImage(named: "Agosto")!))
        Month.append(MonthData(monthname: "Septiembre", monthimage: UIImage(named: "Septiembre")!))
        Month.append(MonthData(monthname: "Octubre", monthimage: UIImage(named: "Octubre")!))
        Month.append(MonthData(monthname: "Noviembre", monthimage: UIImage(named: "Noviembre")!))
        Month.append(MonthData(monthname: "Diciembre", monthimage: UIImage(named: "Diciembre")!))

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Month.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MONTH", for: indexPath)
        
        cell.textLabel?.text = "\(Month[indexPath.row].monthname)"
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SELECTEDMONTH" {
            
            let indexPath = MONTHTABLE.indexPathForSelectedRow
            let destination = segue.destination as! MonthViewController
            
            destination.Months = Month[(indexPath?.row)!]
            
        }
    }
}
